/***********************************************************************
 * COSC1076 - Advanced Programming Techniques
 * Semester 2 2014 Assignment #1 
 * Full Name        : EDIT HERE
 * Student Number   : EDIT HERE
 * Course Code      : EDIT HERE
 * Program Code     : EDIT HERE
 * Start up code provided by Paul Miller and Virginia King
 **********************************************************************/
#include "draughts.h"

int main (int argc, char *argv[])
{
    struct result scoreboard[SCOREBOARDSIZE];
    
    /* Delete this comment and write your own code here */
    
    return EXIT_SUCCESS;
}
